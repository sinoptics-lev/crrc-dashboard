import { useState, useMemo, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { formatDate } from '@/lib/date';
import { AIAnalysisPanel } from '@/components/AIAnalysisPanel';
import type { Project } from '@/types/project';

interface Props {
  projects: Project[];
}

const PAGE_SIZE = 20;

type SortKey = 'name' | 'department' | 'mingos' | 'laborRelease' | 'economicEffect' | 'costTotal' | 'delta';

interface SortState {
  key: SortKey;
  asc: boolean;
}

function Pagination({ totalPages, currentPage, onPageChange }: { totalPages: number; currentPage: number; onPageChange: (p: number) => void }) {
  const siblings = 2;
  const range = [] as (number | '...')[];

  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || (i >= currentPage - siblings && i <= currentPage + siblings)) {
      range.push(i);
    } else if (range[range.length - 1] !== '...') {
      range.push('...');
    }
  }

  return (
    <div className="flex gap-1.5 justify-center mt-4 flex-wrap">
      {currentPage > 1 && (
        <button
          className="px-3 py-1.5 rounded-md text-[0.85rem] border bg-white text-[#1a202c] border-[#e2e8f0] cursor-pointer hover:bg-[#f0f4f8] transition-colors"
          onClick={() => onPageChange(currentPage - 1)}
        >
          ←
        </button>
      )}
      {range.map((item, i) =>
        item === '...' ? (
          <span key={`dots-${i}`} className="px-2 py-1.5 text-[0.85rem] text-[#718096]">...</span>
        ) : (
          <button
            key={item}
            className={`px-3 py-1.5 rounded-md text-[0.85rem] border cursor-pointer transition-colors ${
              item === currentPage
                ? 'bg-[#1a56db] text-white border-[#1a56db]'
                : 'bg-white text-[#1a202c] border-[#e2e8f0] hover:bg-[#f0f4f8]'
            }`}
            onClick={() => onPageChange(item)}
          >
            {item}
          </button>
        )
      )}
      {currentPage < totalPages && (
        <button
          className="px-3 py-1.5 rounded-md text-[0.85rem] border bg-white text-[#1a202c] border-[#e2e8f0] cursor-pointer hover:bg-[#f0f4f8] transition-colors"
          onClick={() => onPageChange(currentPage + 1)}
        >
          →
        </button>
      )}
    </div>
  );
}

export function ProjectsTable({ projects }: Props) {
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState<SortState>({ key: 'name', asc: true });
  const [modalProject, setModalProject] = useState<Project | null>(null);
  const [modalTab, setModalTab] = useState<'main' | 'ai'>('main');

  useEffect(() => {
    if (modalProject) setModalTab('main');
  }, [modalProject?.id]);

  const handleSort = useCallback((key: SortKey) => {
    setSort(prev => ({ key, asc: prev.key === key ? !prev.asc : true }));
    setPage(1);
  }, []);

  const sorted = useMemo(() => {
    const result = [...projects];
    result.sort((a, b) => {
      const { key, asc } = sort;
      let va: string | number;
      let vb: string | number;
      switch (key) {
        case 'name': va = a.name; vb = b.name; break;
        case 'department': va = a.department; vb = b.department; break;
        case 'mingos': va = a.mingos; vb = b.mingos; break;
        case 'laborRelease': va = a.laborRelease; vb = b.laborRelease; break;
        case 'economicEffect': va = a.effectAmount; vb = b.effectAmount; break;
        case 'costTotal': va = a.costTotal; vb = b.costTotal; break;
        case 'delta': va = a.delta; vb = b.delta; break;
        default: va = a.name; vb = b.name;
      }
      if (typeof va === 'string') { va = va.toLowerCase(); vb = (vb as string).toLowerCase(); }
      if (va < vb) return asc ? -1 : 1;
      if (va > vb) return asc ? 1 : -1;
      return 0;
    });
    return result;
  }, [projects, sort]);

  const totalPages = Math.ceil(sorted.length / PAGE_SIZE);
  const paginated = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const SortIcon = ({ colKey }: { colKey: SortKey }) => (
    <span className={`ml-1 text-[0.7rem] opacity-50 ${sort.key === colKey ? 'opacity-100 text-[#1a56db]' : ''}`}>
      {sort.key === colKey ? (sort.asc ? '\u2191' : '\u2193') : '\u2195'}
    </span>
  );

  const getEfficiencyBadge = (delta: number) => {
    if (delta > 500) return { label: 'Исключ.', color: 'bg-[#bbf7d0] text-[#15803d]' };
    if (delta > 100) return { label: 'Оч. выс.', color: 'bg-[#dcfce7] text-[#16a34a]' };
    if (delta > 10) return { label: 'Высок.', color: 'bg-[#f0fdf4] text-[#22c55e]' };
    if (delta >= 0) return { label: 'Окуп.', color: 'bg-[#eff6ff] text-[#2563eb]' };
    if (delta > -10) return { label: 'Незн.уб.', color: 'bg-[#fef2f2] text-[#f87171]' };
    if (delta > -100) return { label: 'Убыток', color: 'bg-[#fee2e2] text-[#dc2626]' };
    return { label: 'Крит.уб.', color: 'bg-[#fee2e2] text-[#7f1d1d]' };
  };

  return (
    <motion.section
      className="bg-white rounded-xl p-6 mb-5 shadow-sm"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.8 }}
    >
      <h2 className="text-[1.1rem] font-bold text-[#1a202c] mb-4 flex items-center gap-2">
        <span className="w-1 h-[22px] bg-[#1a56db] rounded-sm" />
        Проекты трансформации
        <span className="text-[0.8rem] font-normal text-[#718096] ml-2">({projects.length} проектов)</span>
      </h2>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-[0.85rem]">
          <thead>
            <tr>
              <th className="py-2.5 px-2 bg-[#f0f4f8] font-semibold text-[0.75rem] uppercase text-[#718096] tracking-wider text-center w-[40px]">#</th>
              {[
                { key: 'name' as SortKey, label: 'Проект', align: 'left' },
                { key: 'department' as SortKey, label: 'Ведомство', align: 'left' },
                { key: 'mingos' as SortKey, label: 'Мингос', align: 'center' },
                { key: 'laborRelease' as SortKey, label: 'Высвобождение (сокращение), чел.', align: 'right' },
                { key: 'economicEffect' as SortKey, label: 'Экономический эффект, млн руб.', align: 'right' },
                { key: 'costTotal' as SortKey, label: 'Затраты, млн руб.', align: 'right' },
                { key: 'delta' as SortKey, label: 'Эффективность', align: 'right' },
              ].map(col => (
                <th
                  key={col.key}
                  className={`py-2.5 px-3 bg-[#f0f4f8] font-semibold text-[0.75rem] uppercase text-[#718096] tracking-wider cursor-pointer select-none border-b border-[#e2e8f0] hover:bg-[#e2e8f0] ${
                    col.align === 'center' ? 'text-center' : col.align === 'right' ? 'text-right' : 'text-left'
                  }`}
                  onClick={() => handleSort(col.key)}
                >
                  {col.label} <SortIcon colKey={col.key} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <AnimatePresence mode="wait">
              {paginated.map((project, idx) => {
                const badge = getEfficiencyBadge(project.delta);
                return (
                  <motion.tr
                    key={project.id}
                    className="border-b border-[#e2e8f0] hover:bg-[#f0f4f8] cursor-pointer transition-colors"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    onClick={() => setModalProject(project)}
                  >
                    <td className="py-2.5 px-2 text-center text-[0.8rem] text-[#718096] font-medium">{(page - 1) * PAGE_SIZE + idx + 1}</td>
                    <td className="py-2.5 px-3">
                      <a
                        href={project.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-bold text-[#1a202c] hover:text-[#1a56db] transition-colors"
                        onClick={e => e.stopPropagation()}
                      >
                        {project.name}
                      </a>
                    </td>
                    <td className="py-2.5 px-3">{project.department}</td>
                    <td className="py-2.5 px-3 text-center">
                      {project.mingos === 'Да' ? (
                        <span className="inline-block px-2 py-0.5 rounded-full text-[0.7rem] font-semibold bg-[#def7ec] text-[#0e9f6e]">Да</span>
                      ) : (
                        <span className="inline-block px-2 py-0.5 rounded-full text-[0.7rem] font-semibold bg-[#fde8e8] text-[#e02424]">Нет</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-right">{project.laborRelease.toLocaleString('ru-RU')}{(project.reductionPlan > 0 ? `(${project.reductionPlan.toLocaleString('ru-RU')})` : '')}</td>
                    <td className="py-2.5 px-3 text-right">{project.effectAmount > 0 ? project.effectAmount.toLocaleString('ru-RU', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '—'}</td>
                    <td className="py-2.5 px-3 text-right">{(project.costTotal / 1000).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[0.7rem] font-semibold ${badge.color}`}>
                        {badge.label} ({project.delta > 0 ? '+' : ''}{project.delta.toLocaleString('ru-RU')})
                      </span>
                    </td>
                  </motion.tr>
                );
              })}
            </AnimatePresence>
          </tbody>
        </table>
      </div>

      {paginated.length === 0 && (
        <div className="text-center py-8 text-[#718096]">Проекты не найдены</div>
      )}

      {totalPages > 1 && (
        <Pagination totalPages={totalPages} currentPage={page} onPageChange={setPage} />
      )}

      {/* Modal */}
      <AnimatePresence>
        {modalProject && (
          <motion.div
            className="fixed inset-0 bg-black/50 z-50 flex justify-center items-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={() => setModalProject(null)}
          >
            <motion.div
              className="bg-white rounded-2xl max-w-[700px] w-full max-h-[85vh] overflow-y-auto p-8 shadow-xl"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-5">
                <div className="pr-4">
                  <h3 className="text-[1.3rem] font-bold text-[#1a202c]">{modalProject.name}</h3>
                  {modalProject.link && (
                    <a href={modalProject.link} target="_blank" rel="noopener noreferrer" className="text-[0.8rem] text-[#1a56db] hover:underline break-all" onClick={e => e.stopPropagation()}>Открыть в РМ →</a>
                  )}
                </div>
                <button className="bg-none border-none text-[1.5rem] text-[#718096] cursor-pointer leading-none hover:text-[#1a202c] transition-colors flex-shrink-0" onClick={() => setModalProject(null)}>&times;</button>
              </div>

              {/* Tabs */}
              {modalProject.aiAnalysis && Object.keys(modalProject.aiAnalysis).length > 0 && (
                <div className="flex gap-1 mb-5 bg-[#f0f4f8] rounded-lg p-1">
                  <button onClick={() => setModalTab('main')} className={`flex-1 px-3 py-2 rounded-md text-[0.8rem] font-semibold border-none cursor-pointer transition-all ${modalTab === 'main' ? 'bg-white text-[#1a202c] shadow-sm' : 'bg-transparent text-[#718096] hover:text-[#1a202c]'}`}>Основные данные</button>
                  <button onClick={() => setModalTab('ai')} className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-md text-[0.8rem] font-semibold border-none cursor-pointer transition-all ${modalTab === 'ai' ? 'bg-white text-[#7c3aed] shadow-sm' : 'bg-transparent text-[#718096] hover:text-[#7c3aed]'}`}><Sparkles className="w-3.5 h-3.5" />ИИ Анализ</button>
                </div>
              )}

              {(!modalProject.aiAnalysis || modalTab === 'main') && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Ведомство</div><div className="text-[1.1rem] font-semibold text-[#1a202c]">{modalProject.department}</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Участие Мингос</div><div className="text-[1.1rem] font-semibold text-[#1a202c]">{modalProject.mingos === 'Да' ? 'Да' : 'Нет'}</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Дата начала</div><div className="text-[0.95rem] text-[#1a202c]">{formatDate(modalProject.startDate)}</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Дата окончания</div><div className="text-[0.95rem] text-[#1a202c]">{formatDate(modalProject.endDate)}</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Высвобождение трудозатрат</div><div className="text-[1.1rem] font-semibold text-[#1a202c]">{modalProject.laborRelease.toLocaleString('ru-RU')} чел.</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Затраты на проект</div><div className="text-[1.1rem] font-semibold text-[#1a202c]">{(modalProject.costTotal / 1000).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} млн руб.</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Эффективность проекта</div><div className="text-[1.1rem] font-semibold text-[#0e9f6e]">{modalProject.economicEffect.toLocaleString('ru-RU', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} млн руб.</div></div>
                    {modalProject.effectAmount > 0 && (
                      <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">{modalProject.effectType || 'Экономический эффект'}</div><div className="text-[1.1rem] font-semibold text-[#7c3aed]">{modalProject.effectAmount.toLocaleString('ru-RU', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} млн руб.</div></div>
                    )}
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Экономическая дельта</div><div className={`text-[1.1rem] font-semibold ${modalProject.delta >= 0 ? 'text-[#0e9f6e]' : 'text-[#e02424]'}`}>{modalProject.delta > 0 ? '+' : ''}{modalProject.delta.toLocaleString('ru-RU')} млн руб.</div></div>
                    <div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Категория эффективности</div>{(() => { const badge = getEfficiencyBadge(modalProject.delta); return <span className={`inline-block px-2 py-0.5 rounded-full text-[0.75rem] font-semibold ${badge.color}`}>{badge.label}</span>; })()}</div>
                  </div>
                  {modalProject.effects && (<div className="mb-4"><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Эффекты проекта</div><div className="text-[0.9rem] text-[#1a202c] leading-relaxed whitespace-pre-wrap bg-[#f8fafc] p-4 rounded-lg">{modalProject.effects}</div></div>)}
                  {modalProject.nonMaterialEffect && (<div><div className="text-[0.75rem] uppercase tracking-wider text-[#718096] mb-1 font-semibold">Нематериальный эффект</div><div className="text-[0.9rem] text-[#1a202c] leading-relaxed whitespace-pre-wrap bg-[#f8fafc] p-4 rounded-lg">{modalProject.nonMaterialEffect}</div></div>)}
                </>
              )}

              {modalTab === 'ai' && modalProject && (
                <AIAnalysisPanel project={modalProject} />
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.section>
  );
}
