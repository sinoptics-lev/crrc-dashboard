<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['analysis' => 'Метод не поддерживается. Используйте POST.']);
    exit;
}

$apiKey = '';
$envFile = __DIR__ . '/../.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, 'DEEPSEEK_API_KEY=') === 0) {
            $apiKey = trim(substr($line, strlen('DEEPSEEK_API_KEY=')));
            break;
        }
    }
}

if (empty($apiKey)) {
    echo json_encode(['analysis' => 'AI-анализ недоступен: не настроен DEEPSEEK_API_KEY. Добавьте ключ в файл .env']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['analysis' => 'Ошибка: не удалось прочитать данные запроса.']);
    exit;
}

$prompt = buildPrompt($input);

$payload = [
    'model' => 'deepseek-chat',
    'messages' => [
        [
            'role' => 'system',
            'content' => 'Ты — экспертный аналитик проектов цифровой трансформации. Анализируй обоснованность проектов на основе предоставленных данных. Отвечай на русском языке. Давай развернутый анализ с конкретными цифрами и четкие рекомендации.'
        ],
        [
            'role' => 'user',
            'content' => $prompt
        ]
    ],
    'max_tokens' => 2000,
    'temperature' => 0.7
];

$ch = curl_init('https://api.deepseek.com/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    echo json_encode(['analysis' => 'Ошибка соединения с Deepseek: ' . $error]);
    exit;
}

if ($httpCode !== 200) {
    echo json_encode(['analysis' => 'Ошибка Deepseek API (HTTP ' . $httpCode . '). Проверьте API-ключ.']);
    exit;
}

$data = json_decode($response, true);
$content = $data['choices'][0]['message']['content'] ?? null;

if ($content) {
    echo json_encode(['analysis' => $content]);
} else {
    echo json_encode(['analysis' => 'Не удалось получить анализ от AI.']);
}

function buildPrompt($data) {
    $sections = [];
    $sections[] = 'Проанализируй обоснованность реализации следующего проекта цифровой трансформации:';
    $sections[] = '\n## Основные данные проекта';
    $sections[] = '- **Название:** ' . ($data['projectName'] ?? '');
    $sections[] = '- **Ведомство:** ' . ($data['department'] ?? '');
    $sections[] = '- **Тема:** ' . ($data['topic'] ?? '');

    if (!empty($data['effects'])) {
        $sections[] = '\n## Эффекты проекта';
        $sections[] = '- **Описание эффектов:** ' . $data['effects'];
        if (!empty($data['effectType']) && ($data['effectAmount'] ?? 0) > 0) {
            $sections[] = '- **Тип эффекта:** ' . $data['effectType'];
            $sections[] = '- **Сумма эффекта:** ' . $data['effectAmount'] . ' млн руб.';
        }
    }

    $sections[] = '\n## Финансовые показатели';
    $sections[] = '- **Заявлено к высвобождению:** ' . ($data['laborClaimed'] ?? 0) . ' чел.';
    $sections[] = '- **План сокращения:** ' . ($data['reductionPlan'] ?? 0) . ' чел.';
    $sections[] = '- **Затраты:** ' . number_format(($data['costTotal'] ?? 0) / 1000, 2) . ' млн руб.';
    $sections[] = '- **Экономический эффект:** ' . number_format($data['economicEffect'] ?? 0, 1) . ' млн руб.';
    $sections[] = '- **Дельта (эффективность):** ' . number_format($data['delta'] ?? 0, 1) . ' млн руб.';

    if (!empty($data['aiAnalysisData'])) {
        $sections[] = '\n## Данные ИИ-анализа';
        foreach ($data['aiAnalysisData'] as $key => $value) {
            $sections[] = '- **' . $key . ':** ' . $value;
        }
    }

    $sections[] = '\n## Требуемый анализ';
    $sections[] = '\nОцени обоснованность реализации проекта по следующим критериям:';
    $sections[] = '1. **Целесообразность:** Оправданы ли затраты ожидаемыми эффектами?';
    $sections[] = '2. **Финансовая эффективность:** Положительна ли дельта проекта?';
    $sections[] = '3. **Риски:** Какие риски могут повлиять на достижение заявленных эффектов?';
    $sections[] = '4. **Рекомендации:** Рекомендуется ли к реализации?';
    $sections[] = '\nОтветь на русском языке. Формат: развернутый анализ с конкретными цифрами.';

    return implode("\n", $sections);
}
