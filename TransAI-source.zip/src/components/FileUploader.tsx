import { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileSpreadsheet, X, Check, ArrowRight, Download, RotateCcw } from 'lucide-react';

interface FileUploaderProps {
  onFilesLoad: (rmFile: File, dbFile: File, aiFile?: File) => void;
  onAIFileLoad: (aiFile: File) => void;
  hasProjectData: boolean;
  isLoading: boolean;
  aiLoading?: boolean;
  fileNames?: { rm?: string | null; db?: string | null; ai?: string | null } | null;
  onClear: () => void;
  onResetToServer?: () => void;
  jsonDownloadUrl?: string | null;
  onExportXLSX?: () => void;
  onExportFullReport?: () => void;
}

function FileDropZone({
  label,
  sublabel,
  file,
  onDrop,
  isLoading,
}: {
  label: string;
  sublabel: string;
  file: File | null;
  onDrop: (f: File) => void;
  isLoading: boolean;
}) {
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].name.endsWith('.xlsx')) {
      onDrop(files[0]);
    }
  }, [onDrop]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onDrop(files[0]);
    }
  }, [onDrop]);

  if (file) {
    return (
      <div className="flex items-center gap-3 bg-green-50 rounded-xl px-4 py-3 border border-green-200">
        <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
          <Check className="w-4 h-4 text-green-600" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[0.75rem] text-[#718096]">{label}</div>
          <div className="text-[0.85rem] font-semibold text-[#1a202c] truncate">{file.name}</div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`relative rounded-xl border-2 border-dashed px-4 py-4 text-center cursor-pointer transition-all ${
        isDragOver
          ? 'border-[#1a56db] bg-[#e1effe]'
          : 'border-[#cbd5e1] bg-white hover:border-[#94a3b8] hover:bg-[#f8fafc]'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input ref={inputRef} type="file" accept=".xlsx" className="hidden" onChange={handleChange} />
      <div className="flex flex-col items-center gap-1.5">
        {isLoading ? (
          <div className="w-8 h-8 rounded-full bg-[#e1effe] flex items-center justify-center animate-spin">
            <Upload className="w-4 h-4 text-[#1a56db]" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-[#e1effe] flex items-center justify-center">
            <FileSpreadsheet className="w-4 h-4 text-[#1a56db]" />
          </div>
        )}
        <div className="text-[0.85rem] font-semibold text-[#1a202c]">{label}</div>
        <div className="text-[0.7rem] text-[#718096]">{sublabel}</div>
      </div>
    </div>
  );
}

export function FileUploader({
  onFilesLoad,
  onAIFileLoad,
  hasProjectData,
  isLoading,
  aiLoading,
  fileNames,
  onClear,
  onResetToServer,
  jsonDownloadUrl,
  onExportXLSX,
  onExportFullReport,
}: FileUploaderProps) {
  const [rmFile, setRmFile] = useState<File | null>(null);
  const [dbFile, setDbFile] = useState<File | null>(null);
  const [aiFile, setAiFile] = useState<File | null>(null);

  const handleRmDrop = useCallback((f: File) => setRmFile(f), []);
  const handleDbDrop = useCallback((f: File) => setDbFile(f), []);
  const handleAiDrop = useCallback((f: File) => setAiFile(f), []);

  const handleLoad = () => {
    if (rmFile && dbFile) {
      onFilesLoad(rmFile, dbFile, aiFile || undefined);
    } else if (aiFile && hasProjectData) {
      onAIFileLoad(aiFile);
    }
  };

  const handleClearLocal = () => {
    setRmFile(null);
    setDbFile(null);
    setAiFile(null);
    onClear();
  };

  const canLoad = (rmFile && dbFile) || (aiFile && hasProjectData);

  if (fileNames?.rm && fileNames?.db) {
    return (
      <motion.div
        className="flex items-center gap-3 bg-white rounded-xl px-4 py-3 shadow-sm border border-green-200"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
          <Check className="w-5 h-5 text-green-600" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[0.85rem] font-semibold text-[#1a202c] truncate">
            Данные загружены: {fileNames.rm} + {fileNames.db}{fileNames.ai ? ' + ' + fileNames.ai : ''}
          </div>
          <div className="text-[0.75rem] text-[#718096]">Для всех пользователей — скачайте JSON и замените на сервере</div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {onExportXLSX && (
            <button
              onClick={onExportXLSX}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#7c3aed] bg-[#f3e8ff] rounded-lg border-none cursor-pointer hover:bg-[#e9d5ff] transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              XLSX
            </button>
          )}
          <button
            onClick={onExportFullReport}
            disabled={!onExportFullReport}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#0e9f6e] bg-[#f0fdf4] rounded-lg border-none cursor-pointer hover:bg-[#dcfce7] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Отчет
          </button>
          {jsonDownloadUrl && (
            <a
              href={jsonDownloadUrl}
              download="projects_data.json"
              className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#1a56db] bg-[#e1effe] rounded-lg border-none cursor-pointer hover:bg-[#bfdbfe] transition-colors no-underline"
              onClick={e => e.stopPropagation()}
            >
              <Download className="w-3.5 h-3.5" />
              JSON
            </a>
          )}
          {onResetToServer && (
            <button
              onClick={onResetToServer}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#059669] bg-[#d1fae5] rounded-lg border-none cursor-pointer hover:bg-[#a7f3d0] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Данные сервера
            </button>
          )}
          <button
            onClick={handleClearLocal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#e02424] bg-[#fee2e2] rounded-lg border-none cursor-pointer hover:bg-[#fecaca] transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            Удалить
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
      <div className="bg-white rounded-xl p-4 shadow-sm border border-[#e2e8f0]">
        <div className="flex items-center justify-between mb-3">
          <div className="text-[0.85rem] font-semibold text-[#1a202c] flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-[#1a56db]" />
            Загрузка данных
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onExportFullReport}
              disabled={!onExportFullReport}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#0e9f6e] bg-[#f0fdf4] rounded-lg border-none cursor-pointer hover:bg-[#dcfce7] transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Отчет
            </button>
            {onResetToServer && (
              <button
                onClick={onResetToServer}
                className="flex items-center gap-1.5 px-3 py-1.5 text-[0.8rem] font-semibold text-[#059669] bg-[#d1fae5] rounded-lg border-none cursor-pointer hover:bg-[#a7f3d0] transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Данные сервера
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <FileDropZone
            label="Данные из РМ"
            sublabel="issues_2026_with_linked*.xlsx"
            file={rmFile}
            onDrop={handleRmDrop}
            isLoading={isLoading}
          />
          <FileDropZone
            label="Данные из ДБ"
            sublabel="Проекты 2026.xlsx"
            file={dbFile}
            onDrop={handleDbDrop}
            isLoading={isLoading}
          />
          <FileDropZone
            label="Аналитика ИИ"
            sublabel="ai_project_analysis.xlsx (опционально)"
            file={aiFile}
            onDrop={handleAiDrop}
            isLoading={aiLoading ?? false}
          />
        </div>

        {canLoad && (
          <motion.div
            className="mt-3 flex items-center gap-3"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={handleLoad}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#1a56db] text-white rounded-lg text-[0.9rem] font-semibold border-none cursor-pointer hover:bg-[#1e429f] transition-colors"
            >
              <ArrowRight className="w-4 h-4" />
              {rmFile && dbFile
                ? (aiFile ? 'Обновить дашборд + ИИ' : 'Обновить дашборд')
                : 'Обновить ИИ-аналитику'}
            </button>
            <span className="text-[0.8rem] text-[#718096]">
              {rmFile && dbFile
                ? 'Связь по ID: РМ (столбец A) ↔ ДБ (столбец L)' + (aiFile ? ' ↔ ИИ (столбец A)' : '')
                : 'Обновление только данных ИИ-аналитики для текущих проектов'}
            </span>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
