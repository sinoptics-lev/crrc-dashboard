import { motion } from 'framer-motion';

export function Header() {
  return (
    <motion.header
      className="w-full rounded-xl px-6 py-8 mb-6 shadow-md"
      style={{
        background: 'linear-gradient(135deg, #1a365d 0%, #1a56db 100%)',
      }}
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
    >
      <h1 className="text-white text-[1.75rem] font-bold mb-2">
        Трансформационные проекты 2026
      </h1>
      <p className="text-white/90 text-[0.95rem]">
        Сводный аналитический дашборд по цифровой трансформации органов исполнительной власти Московской области
      </p>
    </motion.header>
  );
}
