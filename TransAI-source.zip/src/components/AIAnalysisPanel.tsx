import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Loader2 } from 'lucide-react';
import { MarkdownRenderer } from './MarkdownRenderer';
import type { Project } from '@/types/project';

interface Props {
  project: Project;
}

export function AIAnalysisPanel({ project }: Props) {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      const response = await fetch('api/analyze.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectName: project.name,
          department: project.department,
          topic: project.topic,
          effects: project.effects,
          effectType: project.effectType,
          effectAmount: project.effectAmount,
          laborClaimed: project.laborClaimed ?? 0,
          reductionPlan: project.reductionPlan,
          costTotal: project.costTotal,
          economicEffect: project.economicEffect,
          delta: project.delta,
          aiAnalysisData: project.aiAnalysis,
        }),
      });
      const result = await response.json();
      setAnalysis(result.analysis);
    } catch (err) {
      setAnalysis('Ошибка при запросе AI-анализа. Проверьте подключение к серверу.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {project.aiAnalysis && Object.keys(project.aiAnalysis).length > 0 && (
        <div className="space-y-3">
          <div className="text-[0.75rem] uppercase tracking-wider text-[#7c3aed] font-semibold">
            Данные из файла аналитики
          </div>
          {Object.entries(project.aiAnalysis).map(([colName, value]) => (
            <div key={colName}>
              <div className="text-[0.75rem] uppercase tracking-wider text-[#7c3aed] mb-1 font-semibold">
                {colName}
              </div>
              <div className="text-[0.9rem] text-[#1a202c] leading-relaxed whitespace-pre-wrap bg-[#faf5ff] p-4 rounded-lg">
                {value}
              </div>
            </div>
          ))}
        </div>
      )}

      <motion.button
        onClick={handleAnalyze}
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#7c3aed] to-[#6d28d9] text-white rounded-xl text-[0.9rem] font-semibold border-none cursor-pointer hover:from-[#6d28d9] hover:to-[#5b21b6] transition-all disabled:opacity-60 disabled:cursor-not-allowed"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Анализирую...
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            {analysis ? 'Перезапустить AI-анализ' : 'Запустить AI-анализ обоснованности'}
          </>
        )}
      </motion.button>

      {analysis && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="text-[0.75rem] uppercase tracking-wider text-[#0e9f6e] mb-2 font-semibold flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" />
            Результат AI-анализа
          </div>
          <div className="text-[0.9rem] text-[#1a202c] leading-relaxed bg-[#f0fdf4] p-4 rounded-lg border border-[#bbf7d0] ai-analysis-content">
            <MarkdownRenderer content={analysis} />
          </div>
        </motion.div>
      )}
    </div>
  );
}
